// Gives the study page the same window.claude.use() it has on claude.ai,
// backed by the app's local server.
(function () {
  'use strict';
  async function post(path, body) {
    const r = await fetch(path, { method: 'POST', headers: { 'content-type': 'application/json', 'x-origonex': '1' }, body: JSON.stringify(body || {}) });
    let j = {}; try { j = await r.json(); } catch (e) {}
    if (!r.ok) throw { code: j.code || 'error', message: j.message || ('HTTP ' + r.status) };
    return j;
  }
  function parseJSON(t) {
    if (typeof t !== 'string') return t;
    const m = t.match(/[\[{][\s\S]*[\]}]/);
    return JSON.parse(m ? m[0] : t);
  }

  // sample
  async function sample(input, opts) {
    opts = opts || {};
    const r = await post('/api/sample', { input: input, modelTier: opts.modelTier || 'default' });
    if (typeof opts.onText === 'function') { try { opts.onText({ text: r.text, delta: r.text }); } catch (e) {} }
    return { text: r.text, truncated: false };
  }
  sample.json = async function (input, opts) {
    const r = await post('/api/sample', { input: input + '\n\nReply with JSON only, no code fences.', modelTier: (opts && opts.modelTier) || 'default' });
    return parseJSON(r.text.replace(/```(?:json)?/gi, ''));
  };
  sample.limits = async function () { return { images: false }; };

  // db
  function snap(id, res) { return { id: id, exists: !!res.exists, data: function () { return res.exists ? res.data : undefined; }, metadata: { fromCache: false, hasPendingWrites: false } }; }
  function docRef(path) {
    const id = path.split('/').pop();
    return {
      id: id, path: path,
      get: async function () { return snap(id, await post('/api/db', { op: 'get', path: path })); },
      set: async function (data) { await post('/api/db', { op: 'set', path: path, data: data }); },
      update: async function (data) { await post('/api/db', { op: 'update', path: path, data: data }); },
      delete: async function () { await post('/api/db', { op: 'delete', path: path }); },
      onSnapshot: function (next, error) {
        let stop = false;
        (async function () { try { const s = await this_get(); if (!stop) next(s); } catch (e) { if (error) error(e); } })();
        function this_get() { return post('/api/db', { op: 'get', path: path }).then(function (r) { return snap(id, r); }); }
        return function () { stop = true; };
      },
      collection: function (sub) { return collRef(path + '/' + sub); }
    };
  }
  function collRef(path, lim) {
    async function get() {
      const r = await post('/api/db', { op: 'list', path: path, limit: lim || 1000 });
      const docs = r.docs.map(function (d) { return snap(d.id, { exists: true, data: d.data }); });
      return { docs: docs, size: docs.length, empty: !docs.length, forEach: function (f) { docs.forEach(f); }, docChanges: function () { return docs.map(function (d, i) { return { type: 'added', doc: d, oldIndex: -1, newIndex: i }; }); }, metadata: { fromCache: false, hasPendingWrites: false } };
    }
    return {
      path: path,
      doc: function (id) { return docRef(path + '/' + (id || (Date.now().toString(36) + Math.random().toString(36).slice(2, 8)))); },
      add: async function (data) { const d = this.doc(); await d.set(data); return d; },
      limit: function (n) { return collRef(path, n); },
      orderBy: function () { return collRef(path, lim); },
      where: function () { return collRef(path, lim); },
      get: get,
      onSnapshot: function (next, error) { let stop = false; get().then(function (s) { if (!stop) next(s); }, function (e) { if (error) error(e); }); return function () { stop = true; }; }
    };
  }
  const db = { doc: docRef, collection: function (p) { return collRef(p); } };

  // user
  const user = { id: async function () { return 'local'; }, me: async function () { return { id: 'local', name: '' }; }, isOwner: function () { return true; }, canEdit: function () { return true; }, can: function () { return true; }, profiles: async function () { return {}; } };

  // mcp (Google Calendar)
  const mcp = {
    callTool: async function (server, tool, input) { const r = await post('/api/mcp', { server: server, tool: tool, input: input || {} }); return { content: [], payload: r.payload }; },
    invalidate: async function () {},
    listTools: async function () { return { servers: [{ server: 'Google Calendar', authStatus: 'unknown', tools: [{ name: 'list_events', description: '' }, { name: 'create_event', description: '' }] }] }; }
  };

  // natural voice (Piper) on the Windows app
  window.origonexTTS = {
    status: function () { return post('/api/tts/status', {}); },
    install: function () { return post('/api/tts/install', {}); },
    speak: async function (text) {
      const r = await fetch('/api/tts', { method: 'POST', headers: { 'content-type': 'application/json', 'x-origonex': '1' }, body: JSON.stringify({ text: text }) });
      if (!r.ok) { let j = {}; try { j = await r.json(); } catch (e) {} throw { code: j.code || 'tts_failed', message: j.message || 'Voice failed' }; }
      return URL.createObjectURL(await r.blob());
    }
  };
  const map = { sample: sample, db: db, user: user, mcp: mcp };
  window.claude = { use: function (name) { return Promise.resolve(map[name] || null); } };
  window.origonexDesktop = true;
})();
