// OrigoNex Learn local server. Runs inside the app, on 127.0.0.1 only.
// Gives the study page what claude.ai gives an artifact: "sample" (Claude, through the
// official Claude Code CLI signed in to the family's own Claude account, never an API key),
// "db" (JSON files in the app's data folder) and "mcp" (Google Calendar).
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { spawn, execFileSync } = require('child_process');

const IS_WIN = process.platform === 'win32';
const CAL_SCOPES = ['https://www.googleapis.com/auth/calendar.events', 'openid', 'email'];

function readJson(p, d = null) { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return d; } }
function writeJson(p, v, secret) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  const t = p + '.' + process.pid + '.tmp';
  fs.writeFileSync(t, JSON.stringify(v, null, 2), secret ? { mode: 0o600 } : undefined);
  fs.renameSync(t, p);
}

exports.start = function start(opts) {
  const { dataDir, codeDir, shellVersion, codeVersion } = opts;
  const log = opts.log || (() => {});
  const openExternal = opts.openExternal || (() => {});
  const P = {
    state: path.join(dataDir, 'state.json'),
    db: path.join(dataDir, 'db'),
    gClient: path.join(dataDir, 'google-client.json'),
    gToken: path.join(dataDir, 'google-token.json'),
    sandbox: path.join(dataDir, 'claude-sandbox'),
    mcpEmpty: path.join(dataDir, 'claude-sandbox', 'no-mcp.json')
  };
  fs.mkdirSync(P.sandbox, { recursive: true });
  fs.writeFileSync(P.mcpEmpty, '{"mcpServers":{}}');
  const state = () => readJson(P.state, {}) || {};
  const setState = patch => writeJson(P.state, { ...state(), ...patch });
  let port = 0;
  let unlockedUntil = 0;

  // ---------- Claude Code ----------
  function findClaude() {
    const home = os.homedir();
    const c = [process.env.ORIGONEX_CLAUDE];
    if (IS_WIN) {
      c.push(path.join(home, '.local', 'bin', 'claude.exe'));
      if (process.env.LOCALAPPDATA) c.push(path.join(process.env.LOCALAPPDATA, 'Programs', 'claude', 'claude.exe'));
      if (process.env.APPDATA) c.push(path.join(process.env.APPDATA, 'npm', 'claude.cmd'));
    } else {
      c.push(path.join(home, '.local', 'bin', 'claude'), '/opt/homebrew/bin/claude', '/usr/local/bin/claude');
    }
    for (const p of c.filter(Boolean)) { try { if (fs.statSync(p).isFile()) return p; } catch {} }
    try {
      const out = IS_WIN ? execFileSync('where', ['claude'], { encoding: 'utf8', windowsHide: true }) : execFileSync('/bin/sh', ['-lc', 'command -v claude'], { encoding: 'utf8' });
      const first = out.split(/\r?\n/).map(s => s.trim()).find(Boolean);
      return first || null;
    } catch { return null; }
  }
  function claudeEnv() {
    const env = { ...process.env };
    delete env.ANTHROPIC_API_KEY;      // always the family's own Claude plan, never an API key
    delete env.ANTHROPIC_AUTH_TOKEN;
    delete env.ELECTRON_RUN_AS_NODE;
    return env;
  }

  let running = 0; const waiting = [];
  const slot = () => new Promise(r => { if (running < 2) { running++; r(); } else waiting.push(r); });
  const release = () => { const n = waiting.shift(); if (n) n(); else running--; };

  async function runClaude(prompt, tier) {
    const exe = findClaude();
    if (!exe) { const e = new Error('Claude Code is not installed on this computer. A parent can install it from Parent setup.'); e.code = 'not_installed'; throw e; }
    await slot();
    try {
      return await new Promise((resolve, reject) => {
        const args = ['-p', '--output-format', 'json', '--model', tier === 'quick' ? 'haiku' : 'sonnet',
          '--max-turns', '1', '--permission-mode', 'dontAsk',
          '--mcp-config', P.mcpEmpty, '--strict-mcp-config',
          '--disallowedTools', 'Bash,PowerShell,Edit,Write,Read,Glob,Grep,WebFetch,WebSearch,NotebookEdit,Task,TodoWrite,Monitor',
          '--append-system-prompt', 'You are the text engine of a school study app. Reply with text only. Never use tools, never read or write files.'];
        const child = spawn(exe, args, { cwd: P.sandbox, env: claudeEnv(), windowsHide: true, shell: /\.cmd$/i.test(exe), stdio: ['pipe', 'pipe', 'pipe'] });
        let out = '', err = '';
        const timer = setTimeout(() => { try { child.kill(); } catch {} }, 150000);
        child.stdout.on('data', d => { out += d; });
        child.stderr.on('data', d => { err += d; });
        child.on('error', e => { clearTimeout(timer); const x = new Error('Could not start Claude Code: ' + e.message); x.code = 'not_installed'; reject(x); });
        child.on('close', code => {
          clearTimeout(timer);
          let res = null;
          const lines = out.trim().split(/\r?\n/).reverse();
          for (const l of lines) { try { const j = JSON.parse(l); if (j && (j.type === 'result' || 'result' in j)) { res = j; break; } } catch {} }
          if (!res) { try { res = JSON.parse(out); } catch {} }
          const text = res && typeof res.result === 'string' ? res.result : '';
          const blob = (err + ' ' + out + ' ' + text).toLowerCase();
          if ((res && res.is_error) || code !== 0 || !text) {
            log('claude error', code, err.slice(-400), out.slice(-400));
            const x = new Error(/login|log in|not logged|authenticat|\/login|credit balance|api key/.test(blob)
              ? 'Claude Code is not signed in to your Claude account. A parent can sign in from Parent setup.'
              : (text || err.trim().split(/\r?\n/).slice(-2).join(' ') || 'Claude stopped with code ' + code));
            x.code = /login|log in|not logged|authenticat|\/login|credit balance|api key/.test(blob) ? 'not_signed_in' : 'claude_error';
            return reject(x);
          }
          resolve(text);
        });
        child.stdin.on('error', () => {});
        child.stdin.end(prompt);
      });
    } finally { release(); }
  }
  function flatten(input) {
    if (typeof input === 'string') return input;
    if (Array.isArray(input)) return input.map(t => (t.role === 'assistant' ? 'Assistant: ' : 'User: ') + (typeof t.content === 'string' ? t.content : JSON.stringify(t.content))).join('\n\n') + '\n\nAssistant:';
    return String(input || '');
  }

  // ---------- db (JSON files) ----------
  const seg = s => String(s).replace(/[^A-Za-z0-9_.@+~-]/g, '_').replace(/^\.+$/, '_');
  function docFile(p) {
    const parts = String(p).split('/').filter(Boolean);
    if (parts.some(x => /^\.+$/.test(x))) throw Object.assign(new Error('Bad path'), { code: 'invalid_argument' });
    if (parts.length < 2 || parts.length % 2) throw Object.assign(new Error('Bad document path: ' + p), { code: 'invalid_argument' });
    return path.join(P.db, ...parts.map(seg)) + '.json';
  }
  function collDir(p) {
    const parts = String(p).split('/').filter(Boolean);
    if (parts.some(x => /^\.+$/.test(x))) throw Object.assign(new Error('Bad path'), { code: 'invalid_argument' });
    if (!parts.length || parts.length % 2 === 0) throw Object.assign(new Error('Bad collection path: ' + p), { code: 'invalid_argument' });
    return path.join(P.db, ...parts.map(seg));
  }
  function merge(a, b) {
    const o = { ...(a || {}) };
    for (const [k, v] of Object.entries(b || {})) {
      if (v && typeof v === 'object' && !Array.isArray(v) && o[k] && typeof o[k] === 'object' && !Array.isArray(o[k])) o[k] = merge(o[k], v);
      else o[k] = v;
    }
    return o;
  }
  function dbOp(b) {
    switch (b.op) {
      case 'get': { const f = docFile(b.path); if (!fs.existsSync(f)) return { exists: false }; return { exists: true, data: readJson(f, {}) }; }
      case 'set': writeJson(docFile(b.path), b.data || {}); return { ok: true };
      case 'update': { const f = docFile(b.path); const cur = fs.existsSync(f) ? readJson(f, {}) : undefined; if (cur === undefined) throw Object.assign(new Error('Document does not exist'), { code: 'invalid_argument' }); writeJson(f, merge(cur, b.data)); return { ok: true }; }
      case 'delete': fs.rmSync(docFile(b.path), { force: true }); return { ok: true };
      case 'list': {
        const dir = collDir(b.path); let files = [];
        try { files = fs.readdirSync(dir).filter(f => f.endsWith('.json')).sort(); } catch {}
        const lim = Math.max(1, Math.min(1000, b.limit || 1000));
        return { docs: files.slice(0, lim).map(f => ({ id: f.slice(0, -5), data: readJson(path.join(dir, f), {}) })) };
      }
      default: throw Object.assign(new Error('Unknown db op'), { code: 'invalid_argument' });
    }
  }

  // ---------- Google Calendar ----------
  const gClient = () => { const j = readJson(P.gClient); const c = j && (j.installed || j.web || j); return c && c.client_id ? { id: c.client_id, secret: c.client_secret } : null; };
  const gStatus = () => { const t = readJson(P.gToken); return { clientConfigured: !!gClient(), connected: !!(t && t.refresh_token), email: (t && t.email) || null }; };
  const pending = new Map();
  const redirect = () => `http://127.0.0.1:${port}/oauth/callback`;
  function gAuthUrl() {
    const c = gClient(); if (!c) throw new Error('Add the Google client file first.');
    const verifier = crypto.randomBytes(48).toString('base64url');
    const challenge = crypto.createHash('sha256').update(verifier).digest('base64url');
    const st = crypto.randomBytes(16).toString('hex');
    pending.set(st, verifier);
    return 'https://accounts.google.com/o/oauth2/v2/auth?' + new URLSearchParams({ client_id: c.id, redirect_uri: redirect(), response_type: 'code', scope: CAL_SCOPES.join(' '), access_type: 'offline', prompt: 'consent', code_challenge: challenge, code_challenge_method: 'S256', state: st });
  }
  async function gCallback(q) {
    const verifier = pending.get(q.get('state'));
    if (!verifier) throw new Error('This sign-in link has expired. Go back to the app and press Connect Google again.');
    pending.delete(q.get('state'));
    if (q.get('error')) throw new Error('Google said: ' + q.get('error'));
    const c = gClient();
    const r = await fetch('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ code: q.get('code'), client_id: c.id, client_secret: c.secret || '', redirect_uri: redirect(), grant_type: 'authorization_code', code_verifier: verifier }) });
    const t = await r.json();
    if (!r.ok) throw new Error('Google sign-in failed: ' + (t.error_description || t.error));
    let email = null;
    if (t.id_token) { try { email = JSON.parse(Buffer.from(t.id_token.split('.')[1], 'base64url').toString()).email; } catch {} }
    writeJson(P.gToken, { refresh_token: t.refresh_token, access_token: t.access_token, expires_at: Date.now() + (t.expires_in - 60) * 1000, email }, true);
    return email;
  }
  async function gToken() {
    const tok = readJson(P.gToken);
    if (!tok || !tok.refresh_token) throw Object.assign(new Error('Google Calendar is not connected. A parent can connect it in Parent setup.'), { code: 'server_not_connected' });
    if (tok.access_token && tok.expires_at > Date.now()) return tok.access_token;
    const c = gClient();
    const r = await fetch('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ client_id: c.id, client_secret: c.secret || '', refresh_token: tok.refresh_token, grant_type: 'refresh_token' }) });
    const t = await r.json();
    if (!r.ok) throw Object.assign(new Error('Google sign-in has expired. A parent can reconnect it in Parent setup.'), { code: 'needs_reauth' });
    tok.access_token = t.access_token; tok.expires_at = Date.now() + (t.expires_in - 60) * 1000;
    writeJson(P.gToken, tok, true);
    return tok.access_token;
  }
  async function gApi(url, init = {}) {
    const at = await gToken();
    const r = await fetch(url, { ...init, headers: { authorization: 'Bearer ' + at, 'content-type': 'application/json', ...(init.headers || {}) } });
    const text = await r.text(); let body = {}; try { body = text ? JSON.parse(text) : {}; } catch {}
    if (!r.ok) throw Object.assign(new Error('Google Calendar: ' + ((body.error && body.error.message) || r.status)), { code: r.status === 401 ? 'needs_reauth' : 'tool_error' });
    return body;
  }
  const toIso = s => { if (!s) return null; const d = new Date(/[zZ]|[+-]\d\d:?\d\d$/.test(s) ? s : s); return isNaN(d) ? null : d.toISOString(); };
  async function mcp(server, tool, input) {
    if (server !== 'Google Calendar') throw Object.assign(new Error('Unknown connector ' + server), { code: 'server_not_connected' });
    if (tool === 'list_calendars') {
      const r = await gApi('https://www.googleapis.com/calendar/v3/users/me/calendarList?maxResults=250');
      return { calendars: (r.items || []).map(c => ({ id: c.id, summary: c.summaryOverride || c.summary, primary: !!c.primary, accessRole: c.accessRole })) };
    }
    const cal = encodeURIComponent((input && input.calendarId) || 'primary');
    const base = `https://www.googleapis.com/calendar/v3/calendars/${cal}/events`;
    if (tool === 'list_events') {
      const now = new Date();
      const q = new URLSearchParams({ singleEvents: 'true', orderBy: 'startTime', maxResults: String(Math.min(250, input.pageSize || 100)), timeMin: toIso(input.startTime) || now.toISOString(), timeMax: toIso(input.endTime) || new Date(now.getTime() + 7 * 864e5).toISOString() });
      const r = await gApi(`${base}?${q}`);
      return { events: r.items || [] };
    }
    if (tool === 'create_event') {
      const ev = { summary: String(input.summary || 'Event').slice(0, 200), description: input.description ? String(input.description).slice(0, 2000) : undefined };
      if (input.allDay) { ev.start = { date: String(input.startTime).slice(0, 10) }; ev.end = { date: String(input.endTime || input.startTime).slice(0, 10) }; }
      else { ev.start = { dateTime: input.startTime, timeZone: input.timeZone || 'Europe/London' }; ev.end = { dateTime: input.endTime, timeZone: input.timeZone || 'Europe/London' }; }
      return gApi(`${base}?sendUpdates=none`, { method: 'POST', body: JSON.stringify(ev) });
    }
    throw Object.assign(new Error('This app may not use ' + tool), { code: 'not_in_manifest' });
  }

  // ---------- parent PIN (same hash the study page stores) ----------
  function pinHash() { const s = readJson(path.join(P.db, 'data', 'users', 'local', 'settings.json'), null); return s && s.pinHash; }
  const pinSet = () => !!pinHash();
  const unlocked = () => !pinSet() || !state().setupDone || Date.now() < unlockedUntil;

  // ---------- windows on the computer (Windows only) ----------
  function openConsole(title, command) {
    if (!IS_WIN) throw new Error('Only available on Windows');
    // verbatim so cmd.exe sees our own quoting: start "Title" cmd.exe /k <command>
    spawn('cmd.exe', ['/d', '/s', '/c', '"start "' + title + '" cmd.exe /k ' + command + '"'], { env: claudeEnv(), detached: true, windowsHide: false, windowsVerbatimArguments: true, stdio: 'ignore', cwd: os.homedir() }).unref();
  }

  // ---------- Piper natural voice (Windows, offline, free) ----------
  const PIPER = {
    zip: 'https://github.com/rhasspy/piper/releases/download/2023.11.14-2/piper_windows_amd64.zip',
    zipSha: 'f3c58906402b24f3a96d92145f58acba6d86c9b5db896d207f78dc80811efcea',
    model: 'https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_GB/jenny_dioco/medium/en_GB-jenny_dioco-medium.onnx',
    cfg: 'https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_GB/jenny_dioco/medium/en_GB-jenny_dioco-medium.onnx.json',
    voice: 'Jenny (British)'
  };
  const TTS_ON = IS_WIN || !!process.env.ORIGONEX_PIPER_TEST;
  const PD = path.join(dataDir, 'piper');
  const PX = { exe: process.env.ORIGONEX_PIPER_TEST || path.join(PD, 'piper', 'piper.exe'), model: path.join(PD, 'voice.onnx'), cfg: path.join(PD, 'voice.onnx.json'), cache: path.join(PD, 'cache') };
  const T = { state: TTS_ON ? 'missing' : 'unsupported', progress: 0, error: null };
  const piperFilesOk = () => { try { return fs.statSync(PX.exe).size > (process.env.ORIGONEX_PIPER_TEST ? 10 : 100000) && fs.statSync(PX.model).size > 20e6 && fs.statSync(PX.cfg).size > 100; } catch { return false; } };
  if (TTS_ON && piperFilesOk() && state().ttsOk) T.state = 'ready';
  async function download(url, dest, base, span) {
    const r = await fetch(url, { redirect: 'follow' });
    if (!r.ok || !r.body) throw new Error('Download failed (' + r.status + ') for ' + url.split('/').pop());
    const total = +r.headers.get('content-length') || 0, tmp = dest + '.part';
    const fd = fs.openSync(tmp, 'w'); let got = 0;
    try { const rd = r.body.getReader(); for (;;) { const { done, value } = await rd.read(); if (done) break; fs.writeSync(fd, value); got += value.length; if (total) T.progress = Math.round(base + span * got / total); } }
    finally { fs.closeSync(fd); }
    fs.renameSync(tmp, dest);
    return got;
  }
  function loadZipLib() {
    try { return require('adm-zip'); } catch {}
    try { return require(path.join(process.resourcesPath || '', 'app', 'node_modules', 'adm-zip')); } catch {}
    return null;
  }
  function extract(zipFile, destDir) {
    const Z = loadZipLib();
    if (Z) { new Z(zipFile).extractAllTo(destDir, true); return Promise.resolve(); }
    return new Promise((res, rej) => {
      const ps = spawn('powershell.exe', ['-NoProfile', '-Command', `Expand-Archive -LiteralPath '${zipFile.replace(/'/g, "''")}' -DestinationPath '${destDir.replace(/'/g, "''")}' -Force`], { windowsHide: true });
      ps.on('close', c => c === 0 ? res() : rej(new Error('Could not unzip the voice engine'))); ps.on('error', rej);
    });
  }
  let synthQ = Promise.resolve();
  function synth(text) {
    const clean = String(text || '').replace(/\s+/g, ' ').trim().slice(0, 1500);
    const h = crypto.createHash('sha1').update(PIPER.model + '|' + clean).digest('hex');
    const cached = path.join(PX.cache, h + '.wav');
    if (fs.existsSync(cached)) return Promise.resolve(fs.readFileSync(cached));
    const job = () => new Promise((resolve, reject) => {
      fs.mkdirSync(PX.cache, { recursive: true });
      const out = cached + '.tmp.wav';
      const child = spawn(PX.exe, ['--model', PX.model, '--config', PX.cfg, '--output_file', out], { cwd: path.dirname(PX.exe), windowsHide: true, stdio: ['pipe', 'ignore', 'pipe'] });
      let err = ''; const timer = setTimeout(() => { try { child.kill(); } catch {} }, 60000);
      child.stderr.on('data', d => { err += d; });
      child.on('error', e => { clearTimeout(timer); reject(e); });
      child.on('close', code => {
        clearTimeout(timer);
        try { const b = fs.readFileSync(out); if (b.length < 1000) throw new Error('empty'); fs.renameSync(out, cached); pruneCache(); resolve(b); }
        catch (e) { log('piper failed', code, err.slice(-300)); reject(new Error('Natural voice failed')); }
      });
      child.stdin.on('error', () => {});
      child.stdin.end(Buffer.from(clean + '\n', 'utf8'));
    });
    const p = synthQ.then(job, job); synthQ = p.catch(() => {}); return p;
  }
  function pruneCache() {
    try { const f = fs.readdirSync(PX.cache).filter(x => x.endsWith('.wav')).map(x => ({ x, t: fs.statSync(path.join(PX.cache, x)).mtimeMs })).sort((a, b) => b.t - a.t); f.slice(400).forEach(o => fs.rmSync(path.join(PX.cache, o.x), { force: true })); } catch {}
  }
  async function ensurePiper() {
    if (!IS_WIN || T.state === 'downloading') return;
    if (piperFilesOk() && state().ttsOk) { T.state = 'ready'; return; }
    T.state = 'downloading'; T.progress = 0; T.error = null;
    try {
      fs.mkdirSync(PD, { recursive: true });
      if (!fs.existsSync(PX.exe)) {
        const z = path.join(PD, 'piper.zip');
        await download(PIPER.zip, z, 0, 25);
        const sha = crypto.createHash('sha256').update(fs.readFileSync(z)).digest('hex');
        if (sha !== PIPER.zipSha) { fs.rmSync(z, { force: true }); throw new Error('Voice engine failed its safety check'); }
        await extract(z, PD); fs.rmSync(z, { force: true });
        if (!fs.existsSync(PX.exe)) throw new Error('Voice engine files missing after unzip');
      }
      T.progress = 25;
      if (!(fs.existsSync(PX.cfg) && fs.statSync(PX.cfg).size > 100)) { await download(PIPER.cfg, PX.cfg, 25, 1); JSON.parse(fs.readFileSync(PX.cfg, 'utf8')); }
      if (!(fs.existsSync(PX.model) && fs.statSync(PX.model).size > 20e6)) await download(PIPER.model, PX.model, 26, 70);
      if (fs.statSync(PX.model).size < 20e6) throw new Error('Voice file looks incomplete');
      T.progress = 97;
      await synth('Hello, I am Nex.');
      setState({ ttsOk: true }); T.state = 'ready'; T.progress = 100; log('piper ready');
    } catch (e) { T.state = 'error'; T.error = e.message; setState({ ttsOk: false }); log('piper setup failed', e.message); }
  }
  if (IS_WIN && T.state !== 'ready') setTimeout(() => ensurePiper(), 20000);

  // ---------- http ----------
  const send = (res, code, body, type = 'application/json') => { res.writeHead(code, { 'content-type': type, 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' }); res.end(type === 'application/json' ? JSON.stringify(body) : body); };
  const fail = (res, e, code = 400) => send(res, code, { code: e.code || 'error', message: e.message || String(e) });
  function readBody(req) { return new Promise((r, j) => { let b = ''; req.on('data', c => { b += c; if (b.length > 5e6) { j(new Error('Too large')); req.destroy(); } }); req.on('end', () => { try { r(b ? JSON.parse(b) : {}); } catch (e) { j(e); } }); }); }
  function page(name) {
    let html = fs.readFileSync(path.join(codeDir, name), 'utf8');
    return html.replace(/<head>/i, '<head>\n<script src="/shim.js"></script>');
  }

  const srv = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://127.0.0.1');
      const host = req.headers.host || '';
      if (host !== `127.0.0.1:${port}`) return send(res, 403, 'Forbidden', 'text/plain');
      if (req.method === 'GET') {
        if (url.pathname === '/') return send(res, 200, page(state().setupDone ? 'app.html' : 'setup.html'), 'text/html; charset=utf-8');
        if (url.pathname === '/setup') return send(res, 200, page('setup.html'), 'text/html; charset=utf-8');
        if (url.pathname === '/shim.js') return send(res, 200, fs.readFileSync(path.join(codeDir, 'shim.js'), 'utf8'), 'text/javascript; charset=utf-8');
        if (url.pathname === '/oauth/callback') {
          try { const email = await gCallback(url.searchParams); return send(res, 200, `<body style="font:17px Segoe UI,sans-serif;padding:40px;background:#070b22;color:#eaf2ff"><h2>Google Calendar connected</h2><p>Signed in as ${String(email || '').replace(/</g, '')}. You can close this tab and go back to OrigoNex Learn.</p></body>`, 'text/html; charset=utf-8'); }
          catch (e) { return send(res, 400, `<body style="font:17px Segoe UI,sans-serif;padding:40px;background:#070b22;color:#eaf2ff"><h2>Couldn't connect Google</h2><p>${String(e.message).replace(/</g, '&lt;')}</p></body>`, 'text/html; charset=utf-8'); }
        }
        return send(res, 404, 'Not found', 'text/plain');
      }
      if (req.method !== 'POST' || req.headers['x-origonex'] !== '1') return send(res, 403, 'Forbidden', 'text/plain');
      const b = await readBody(req);
      switch (url.pathname) {
        case '/api/sample': {
          const text = await runClaude(flatten(b.input), b.modelTier);
          return send(res, 200, { text });
        }
        case '/api/db': return send(res, 200, dbOp(b));
        case '/api/mcp': return send(res, 200, { payload: await mcp(b.server, b.tool, b.input || {}) });
        case '/api/state': {
          const exe = findClaude();
          return send(res, 200, { shellVersion, codeVersion, platform: process.platform, claude: { installed: !!exe, checkedOk: !!state().claudeOk }, google: gStatus(), setupDone: !!state().setupDone, pinSet: pinSet(), unlocked: unlocked() });
        }
        case '/api/unlock': {
          const h = crypto.createHash('sha256').update('studyhub:' + String(b.pin || '')).digest('hex');
          if (!pinSet() || h === pinHash()) { unlockedUntil = Date.now() + 15 * 60e3; return send(res, 200, { ok: true }); }
          return send(res, 200, { ok: false });
        }
        case '/api/tts/status': return send(res, 200, { ...T, voice: PIPER.voice });
        case '/api/tts/install': { ensurePiper(); return send(res, 200, { ...T }); }
        case '/api/tts': {
          if (T.state !== 'ready') return fail(res, Object.assign(new Error('Natural voice not ready'), { code: 'tts_not_ready' }));
          try { const wav = await synth(b.text); res.writeHead(200, { 'content-type': 'audio/wav', 'cache-control': 'no-store' }); return res.end(wav); }
          catch (e) { return fail(res, Object.assign(e, { code: 'tts_failed' })); }
        }
        case '/api/open': {
          if (/^https:\/\//.test(b.url || '')) openExternal(b.url);
          return send(res, 200, { ok: true });
        }
      }
      // everything below changes the setup, so needs the parent PIN once setup is finished
      if (!unlocked()) return fail(res, Object.assign(new Error('Enter the parent PIN first.'), { code: 'locked' }), 403);
      switch (url.pathname) {
        case '/api/claude/install': openConsole('Install Claude Code', 'powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://claude.ai/install.ps1 | iex"'); return send(res, 200, { ok: true });
        case '/api/claude/signin': {
          const exe = findClaude(); if (!exe) return fail(res, Object.assign(new Error('Install Claude Code first.'), { code: 'not_installed' }));
          openConsole('Sign in to Claude', '"' + exe + '"'); return send(res, 200, { ok: true });
        }
        case '/api/claude/test': {
          try { const t = await runClaude('Reply with the single word READY', 'quick'); const ok = /ready/i.test(t); setState({ claudeOk: ok }); return send(res, 200, { ok, message: ok ? 'Claude is ready' : 'Unexpected reply: ' + t.slice(0, 80) }); }
          catch (e) { setState({ claudeOk: false }); return send(res, 200, { ok: false, code: e.code, message: e.message }); }
        }
        case '/api/google/client': {
          const j = typeof b.json === 'string' ? JSON.parse(b.json) : b.json; const c = j && (j.installed || j.web || j);
          if (!c || !c.client_id) return fail(res, new Error('That file does not look like a Google OAuth client file (no client_id).'));
          writeJson(P.gClient, j, true); return send(res, 200, { ok: true });
        }
        case '/api/google/connect': { openExternal(gAuthUrl()); return send(res, 200, { ok: true }); }
        case '/api/google/disconnect': fs.rmSync(P.gToken, { force: true }); return send(res, 200, { ok: true });
        case '/api/setup/done': setState({ setupDone: true }); return send(res, 200, { ok: true });
      }
      return send(res, 404, { code: 'not_found', message: 'Unknown endpoint' });
    } catch (e) {
      log('server error', e.stack || e.message);
      return fail(res, e, e.code === 'locked' ? 403 : 400);
    }
  });
  return new Promise((resolve, reject) => {
    const want = state().port || 0;
    const tryListen = p => {
      srv.once('error', err => { if (p) tryListen(0); else reject(err); });
      srv.listen(p, '127.0.0.1', () => { port = srv.address().port; if (port !== want) setState({ port }); resolve({ port, close: () => srv.close() }); });
    };
    tryListen(want);
  });
};
